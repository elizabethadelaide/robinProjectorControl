#!/bin/bash

#insall xcode commandline tools
command -v ruby >/dev/null 2>&1 || xcode-select --install

